//
//  SchoolAppApp.swift
//  SchoolApp
//
//  Created by MB User  on 01/03/25.
//

import SwiftUI

@main
struct SchoolAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
