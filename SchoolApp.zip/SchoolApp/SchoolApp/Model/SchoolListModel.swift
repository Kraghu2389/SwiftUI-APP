//
//  SchoolListModel.swift
//  SchoolApp
//
//  Created by MB User  on 01/03/25.
//

import SwiftUI

class SchoolListModel: Identifiable {
    let id = UUID()
    let schoolInfo: SchoolInfoModel
    
    init(schoolInfo: SchoolInfoModel) {
        self.schoolInfo = schoolInfo
    }
    
    var name: String {
        return schoolInfo.schoolName ?? ""
    }
    
    var description: String {
        return schoolInfo.schoolDes ?? ""
    }
    
    var email: String {
        return schoolInfo.email ?? ""
    }
}
