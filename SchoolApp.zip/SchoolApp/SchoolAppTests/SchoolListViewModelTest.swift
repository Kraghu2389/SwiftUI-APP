//
//  SchoolListViewModelTest.swift
//  SchoolApp
//
//  Created by MB User  on 02/03/25.
//

import XCTest
@testable import SchoolApp

final class SchoolListViewModelTest: XCTestCase {

    var schoolListRepo = MockSchoolListRepository()
    private var viewmodel: SchoolsListViewModel!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        viewmodel = SchoolsListViewModel(schoolListRepo: schoolListRepo)
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func test_getScholsList() {
        // Given
        viewmodel.getSchoolsList()
        
        //Then
        XCTAssertEqual(viewmodel.schoolList.count, 1)
    }

}

class MockSchoolListRepository: SchoolListAPIRepository {
    func getSchoolsList(completion: @escaping ([SchoolApp.SchoolListModel], Bool) -> Void) {
        completion([SchoolApp.SchoolListModel.init(
            schoolInfo: SchoolApp.SchoolInfoModel(dbn: "",
                                                  schoolName: "abc",
                                                  schoolDes: "test",
                                                  email: "test@gmail.com"))],
                   true)
    }
}
