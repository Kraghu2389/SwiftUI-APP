//
//  NetworkManager.swift
//  SchoolApp
//
//  Created by MB User  on 01/03/25.
//

import UIKit
import Foundation

class NetworkManager {
    // load data
    static func loadData(url: URL, completion: @escaping ([SchoolInfoModel]?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                completion(nil)
                return
            }
            
            if let response = try? JSONDecoder().decode([SchoolInfoModel].self, from: data) {
                DispatchQueue.main.async {
                    completion(response)
                }
            }
        }.resume()
    }
}
