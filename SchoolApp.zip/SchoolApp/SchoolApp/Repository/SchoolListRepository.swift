//
//  SchoolListRepository.swift
//  SchoolApp
//
//  Created by MB User  on 02/03/25.
//

import Foundation

protocol SchoolListAPIRepository {
    func getSchoolsList(completion: @escaping ([SchoolListModel], Bool) -> Void )
}

struct SchoolListRepository: SchoolListAPIRepository {
    func getSchoolsList(completion: @escaping ([SchoolListModel], Bool) -> Void ) {
        guard let url = URL(string: AppConstants.getSchoolsList) else {
            completion([], false)
            return
        }
        NetworkManager.loadData(url: url) { schoolsInfo in
            if let schoolInfo = schoolsInfo {
                completion(schoolInfo.map(SchoolListModel.init), true)
            } else {
                completion([], false)
            }
        }
    }
}
