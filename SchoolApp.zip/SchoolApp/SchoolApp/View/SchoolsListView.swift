//
//  SchoolsListView.swift
//  SchoolApp
//
//  Created by MB User  on 01/03/25.
//

import SwiftUI

struct SchoolsListView: View {
    
    // MARK: - ObservedObject Vars
    @StateObject var viewModel = SchoolsListViewModel()
    
    var body: some View {
        VStack {
            List(viewModel.schoolList) { schoolInfo in
                VStack(alignment: .leading) {
                    Text(schoolInfo.name)
                    Text(schoolInfo.email)
                        .foregroundColor(.secondary)
                    // Text(schoolInfo.description)
                }
            }
        }
        .onAppear {
            // Call list service
            viewModel.getSchoolsList()
        }
    }
}
