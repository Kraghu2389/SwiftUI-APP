//
//  SchoolsListViewModel.swift
//  SchoolApp
//
//  Created by MB User  on 01/03/25.
//

import SwiftUI

class SchoolsListViewModel: ObservableObject {
    
    // MARK: - Published Vars
    @Published var schoolList = [SchoolListModel]()
    
    //i Vars
    var schoolListRepo: SchoolListAPIRepository
    
    // init methid
    init(schoolListRepo: SchoolListAPIRepository = SchoolListRepository()) {
        self.schoolListRepo = schoolListRepo
    }
    
    // get Schools List method
    func getSchoolsList() {
        self.schoolListRepo.getSchoolsList() { schoolListResponse, success -> Void in
            if success {
                self.schoolList = schoolListResponse
            } else {
                debugPrint("Error Fetching data")
            }
        }
    }
}
