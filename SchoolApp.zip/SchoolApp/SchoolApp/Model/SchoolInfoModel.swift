//
//  SchoolInfoModel.swift
//  SchoolApp
//
//  Created by MB User  on 01/03/25.
//

import UIKit

struct SchoolInfoModel: Codable {
    let dbn: String?
    let schoolName: String?
    let schoolDes: String?
    let email: String?
    
    enum CodingKeys: String, CodingKey {
        case dbn
        case schoolName = "school_name"
        case schoolDes = "overview_paragraph"
        case email = "school_email"
    }
}
