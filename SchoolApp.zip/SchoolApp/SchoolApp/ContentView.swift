//
//  ContentView.swift
//  SchoolApp
//
//  Created by MB User  on 01/03/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            SchoolsListView()
        }
        .padding()
    }
}
