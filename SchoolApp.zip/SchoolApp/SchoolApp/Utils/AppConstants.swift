//
//  AppConstants.swift
//  SchoolApp
//
//  Created by MB User  on 01/03/25.
//

struct AppConstants {
    
    //API
    static let getSchoolsList = "https://data.cityofnewyork.us/resource/s3k6-pzi2.json"
}
